 $('#cosmo').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/cosmo.css'); 
    })
    
    $('#carulean').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/carulen.css'); 
    })
    $('#cyborg').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/cyborg.css'); 
    })
    
    $('#darkhy').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/darkhy.css'); 
    })
    
    $('#flaty').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/flaty.css'); 
    })
    
    $('#journal').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/journal.css'); 
    })
    
    $('#lumen').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/lumen.css'); 
    })
    
    $('#peper').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/peper.css'); 
    })
    
    $('#readeable').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/readeable.css'); 
    })
    
    $('#sandstone').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/sandstone.css'); 
    })
    
    $('#simplex').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/simplex.css'); 
    })
    
     $('#slate').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/slate.css'); 
    }) 
     
     $('#spacelab').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/spacelab.css'); 
    })
     
     $('#superhero').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/superhero.css'); 
    })
     
     $('#united').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/united.css'); 
    })  
     $('#yeti').click(function(){
       var link = document.getElementById('changable');
    link.setAttribute('href', 'css/yeti.css'); 
    })
     
    /* 
       $('#user_guide').click(function(){
          console.log('asdsad')
        $('.changable_header').text(index.search("demo-1"))
    })*/